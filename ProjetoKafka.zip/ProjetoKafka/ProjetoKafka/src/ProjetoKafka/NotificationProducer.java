package ProjetoKafka;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import java.util.Properties;

public class NotificationProducer {
    private KafkaProducer<String, String> producer;

    public NotificationProducer() {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        producer = new KafkaProducer<>(props);
    }

    public void sendNotification(String topic, String message) {
        producer.send(new ProducerRecord<>(topic, message));
        System.out.println("Notification sent: " + message);
    }

    public void closeProducer() {
        producer.close();
    }

    public static void main(String[] args) {
        NotificationProducer notificationProducer = new NotificationProducer();
        
        // Simulando o envio de notificações
        notificationProducer.sendNotification("high-priority", "Palestra de última hora - Alta prioridade");
        notificationProducer.sendNotification("low-priority", "Lembrete de entrega de trabalho - Baixa prioridade");
        
        notificationProducer.closeProducer();
    }
}
