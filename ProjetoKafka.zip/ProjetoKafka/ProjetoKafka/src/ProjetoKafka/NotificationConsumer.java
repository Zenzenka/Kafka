package ProjetoKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class NotificationConsumer {

    @KafkaListener(topics = "high-priority", groupId = "notification-group", containerFactory = "kafkaListenerContainerFactory")
    public void consumeRealTimeNotifications(String message) {
        System.out.println("Real-time Notification Received: " + message);
        // Simulação de envio imediato de notificação
    }

    @KafkaListener(topics = "low-priority", groupId = "notification-group", containerFactory = "batchKafkaListenerContainerFactory")
    public void consumeBatchNotifications(List<String> messages) {
        System.out.println("Batch Notifications Received: " + messages);
        // Simulação de envio de notificações em lote
    }
}
